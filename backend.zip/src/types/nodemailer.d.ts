declare module 'nodemailer'
